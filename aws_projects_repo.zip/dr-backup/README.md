# Disaster Recovery & Backup (template)
Terraform skeleton for AWS Backup plans, vaults, and backup selections. Includes a small Lambda for restore verification.

**Important:** Replace placeholders and provide appropriate IAM roles and KMS keys before applying.
